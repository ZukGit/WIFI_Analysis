package com.example.administrator.bufknife;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import butterknife.BindColor;
import butterknife.BindDimen;
import butterknife.BindDrawable;
import butterknife.BindInt;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

//    //绑定字符串
//    @BindString(R.string.title)
//    String title;
//    //绑定图形
//    @BindDrawable(R.drawable.graphic)
//    Drawable graphic;
//    //绑定颜色
//    @BindColor(R.color.red)
//    int red; // int or ColorStateList field
//    //绑定长度
//   @BindDimen(R.dimen.spacer)
//   int spacer;
//
//
//    //@BindView绑定控件，省去了写findviewbyid的重复性操作
//    @BindView(R.id.title)
//     TextView titleText;
//
//    @BindView(R.id.sub_title)
//     TextView subTitleText;
//
//    @BindView(R.id.footer)
//     TextView footerText;
//
//    @BindView(R.id.list1)
//     ListView listView;
//
//    @BindView(R.id.btn1)
//     Button btn1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.textview);
        ButterKnife.bind(this);
    }
}
